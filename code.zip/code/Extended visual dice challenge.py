#Objective 4: Challenges
#Extended visual dice challenge
#program that asks user for a number and outputs it as a dice
Number = int(input("Enter a number 1 - 6 "))
if Number == 6:
    print("oooooooooooo")
    print("o  #    #  o")
    print("o          o")
    print("o  #    #  o")
    print("o          o")
    print("o  #    #  o")
    print("oooooooooooo")
elif Number == 5:
    print("oooooooooooo")
    print("o  #    #  o")
    print("o          o")
    print("o     #    o")
    print("o          o")
    print("o  #    #  o")
    print("oooooooooooo")
elif Number == 4:
    print("oooooooooooo")
    print("o          o")
    print("o  #    #  o")
    print("o          o")
    print("o  #    #  o")
    print("o          o")
    print("oooooooooooo")
elif Number == 3:
    print("oooooooooooo")
    print("o  #       o")
    print("o          o")
    print("o    #     o")
    print("o          o")
    print("o       #  o")
    print("oooooooooooo")
elif Number == 2:
    print("oooooooooooo")
    print("o          o")
    print("o  #       o")
    print("o          o")
    print("o       #  o")
    print("o          o")
    print("oooooooooooo")
elif Number == 1:
    print("oooooooooooo")
    print("o          o")
    print("o          o")
    print("o    #     o")
    print("o          o")
    print("o          o")
    print("oooooooooooo")
else:
    print("Number wasn't in the range 1 - 6")




