#Objective 2:Challenges
#Simple adder challenge
#Program that asks the user for two numbers,
#adds them together and outputs for example: "you entered 5 and 12. they add to 17"
Number1 = int(input("Enter a first number "))
Number2 = int(input("Enter a second number "))
Total = Number1 + Number2
print("You entered numbers",Number1,"and",Number2)
print("They add up to",Total)
