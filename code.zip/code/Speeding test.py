speed = int(input("How fast are they going?"))
if speed >= 75:
    print("Issue Fine")
elif speed <= 69:
    print("No Action")
else:
    print("Issue Warning")
