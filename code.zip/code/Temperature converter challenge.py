#Objective 2:Challenges
#Temprature converter challenge
#Program that allows the under to enter a temperature in farenheit and display it in centigrade
FarenheitTemp = int(input("Enter a temperature in degrees farenheit"))
CentigradeTemp = (FarenheitTemp-32)*(5/9)
print("You entered",FarenheitTemp,"Degrees Farenheit which is equal to",CentigradeTemp,"Degrees Farenheit")
                    
