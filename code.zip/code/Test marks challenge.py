#Objective 2: Challenges
#Test Marks Challenge
#program that will ask the user 3 test marks out of 100 and output the average
TestMark1 = int(input("Enter the first test mark"))
TestMark2 = int(input("Enter the second test mark"))
TestMark3 = int(input("Enter the third test mark"))
Average = (TestMark1 + TestMark2 + TestMark3)/3
print("The Average mark is",Average)
