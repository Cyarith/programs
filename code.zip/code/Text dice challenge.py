#Objective 9:Challenges
#Text dice challenge
#No condition statements dice
def Dice():
    import random
    c = ["One", "Two", "Three", "Four", "Five", "Six"]
    a = random.choice(c)
    return a
#Main program
print(Dice())

    
