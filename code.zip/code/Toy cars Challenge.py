#Objective 2:Challenges
#Toy cars challenge
#program that works out a worker's wage depending on how many cars made and how many hours work
HoursWorked = float(input("How many hours have you worked?"))
ToyCarsMade = float(input("How many toy cars have you made?"))
Wage = (ToyCarsMade*0.6)+(HoursWorked*9)
print("Your wage for today is",Wage)
