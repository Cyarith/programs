age = int(input("What is your age?: "))
print("Your age is:",age)
