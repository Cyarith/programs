#Challenge 11
sentence = input("Enter a sentence: ")
characters = len(sentence)
print("there are",characters,"characters in your sentence")
