#Challenge 12
sentence = input("Enter a sentence: ")
uppercase = sentence.upper()
print(uppercase)
