#Challenge 13
sentence = input("Enter a sentence: ")
replace = input("What word would you like to replace?: ")
newword = input("Enter the new word: ")
newsentence = sentence.replace(replace,newword)
print(newsentence)
