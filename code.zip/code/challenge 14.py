#Challenge 14
sentence = input("Enter a sentence: ")
foundword = sentence.count("the")
print("The word The appeared",foundword,"Times")
