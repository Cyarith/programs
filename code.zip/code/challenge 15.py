#Challenge 15
sentence = input("Enter a sentence: ")
lowercase = sentence.lower()
print(lowercase)
