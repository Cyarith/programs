#Challenge 16
number = 0
for i in range(10):
    number += 1
    print(number)
