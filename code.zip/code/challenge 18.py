#Challenge 18
number = int(input("Enter a number: "))
numbermult = 0
for i in range(number):
    numbermult += number
    print(numbermult)
    
