#Challenge 19
number = int(input("Enter a number: "))
numberdifference = 0
while True:
    for i in range(number):
        numberdifference += number
        print(numberdifference)
    numberdifference = 0
