number1 = int(input("Enter one number: "))
number2 = int(input("Enter another number: "))
average = (number1 + number2) / 2
print("the average is",average)
