width = int(input("Enter the width of the rectangle: "))
height = int(input("Enter the height of the rectangle: "))
area = width * height
print("The area of the rectangle is",area)
