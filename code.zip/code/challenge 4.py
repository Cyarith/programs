#Challenge 4
number1 = int(input("Enter your first number: "))
number2 = int(input("Enter your second number: "))
result = number1 / number2
print("Dividing your first number by the second number, the result is",result)
