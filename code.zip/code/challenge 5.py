#Challenge 5
name = input("Enter your name: ")
subject = input("Enter your favourite subject: ")
print(name,"I like",subject,"too!")
