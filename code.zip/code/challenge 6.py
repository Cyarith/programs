#Challenge 6
name = input("What's your name?: ")
if name == "Dawud" or name == "dawud":
    print("You're cool")
else:
    print("Nice to meet you")
