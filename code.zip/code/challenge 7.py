#Challenge 7
tvhours = float(input("Enter how long you watch TV each day on average: "))
if tvhours < 2:
    print("That shouldn't rot your brain too much")
elif tvhours < 4:
    print("Aren't you getting square eyes?")
else:
    print("Fresh air beats channel flicking")
