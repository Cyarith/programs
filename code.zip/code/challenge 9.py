#Challenge 9
guess = input("What is one of the Olympic Values?: ")
if guess == "Respect" or guess == "Excellence" or guess == "Friendship":
    print("That's correct")
else:
    print("Try again")
