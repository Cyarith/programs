Number = int(input("Enter a Number."))
print(Number+Number)
