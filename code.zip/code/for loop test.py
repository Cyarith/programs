#testing how a for loop works with 2 number ranges
for counter in range(17,31):
    print(counter)
