grade = int(input("what is your grade?"))
if grade >= 80:
    print("Distinction")
elif grade >= 70:
    print("Merit")
elif grade >= 60:
    print("Pass")
else:
    print("Fail")
