HeadSize = int(input("what is the circumference of your head in cm?"))
if HeadSize <57:
    print("SMALL hat")
elif HeadSize >60:
    print("LARGE hat")
else:
    print("MEDIUM hat")
