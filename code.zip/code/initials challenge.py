#Objective 3:Challenges
#initials and surname challenge
firstname = str(input("enter your first name "))
surname = str(input("enter your second name "))
initial = firstname[0]
upperinitial = initial.upper()
uppersurname = surname.upper()
print(upperinitial,uppersurname)

