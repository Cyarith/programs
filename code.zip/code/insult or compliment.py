choice = str(input("Choose an (I)nsult or a (C)ompliment: "))
if choice == "I":
    print("You are very fat")
elif choice == "i":
    print("You are very fat")
elif choice == "C":
    print("You're a nice person")
elif choice == "c":
    print("You're a nice person")
else:
    print("Sorry, the program did not understand your response.")
    
    
