highscore = [1,2,3,4]
print(highscore)
print(highscore[0])
print(highscore[1])
print(highscore[2])
print(highscore[3])
highscore[0] = 5
print(highscore)
highscore = 128
print(highscore)
highscore = [1,2,3,4]
highscore.append(248)
print(highscore)
