#Objective 7:Challenges
#menu selection challenge
selection = 0
print("1. Play Game")
print("2. Instructions")
print("3. Quit")
while selection == selection:
    selection = input(" ")
    if selection == "1":
        print("Let's go")
    elif selection == "2":
        print("Let's go")
    elif selection == "3":
        print("Let's go")
    else:
        print("1. Play Game")
        print("2. Instructions")
        print("3. Quit")
