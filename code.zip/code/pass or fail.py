Marks = int(input("Please enter the marks of the student"))
if  Marks <40:
    print("FAIL")
else:
    print("PASS")
