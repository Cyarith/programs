print("Please input an integer x: ")
x = input()
print("Please input a second integer y: ")
y = input()
z = x - y
print("x - y = " + z)
