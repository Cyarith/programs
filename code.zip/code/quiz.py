print("WELCOME TO THE QUIZ!") # code for a quiz
print("Question 1.What's the best game?")
print("A - Minecraft")
print("B - Fortnite")
print("C - Roblox")
Question = str(input("Please enter one of the letters here: ")) 
if Question == "a" or Question == "A":
    print("Good, you have a good taste of games.")
else:
    print("Wow. i'm dissapointed in you for this")
    









