#speed camera code
speed = int(input("How fast are they going?"))
if speed >=75:
    print("Issue Fine")
elif speed <70:
    print("No Action")
else:
    print("Issue Warning")

