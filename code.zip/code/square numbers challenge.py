#Objective 6: challenges
#square numbers challenge
#make a program to output all the squares of the numbers 1 to 20
for counter in range(21):
    squaredcounter = counter * counter
    print(counter,"squared is",squaredcounter)
    
    

