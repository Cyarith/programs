

switch(i)
case 0:
        return("no")
