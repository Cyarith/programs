#Objective 4:Challenges
#Underage challenge
#program that asks for the user's age, if they are over 18 it outputs "over 18", otherwise it puts "under 18"
Age = int(input("What is your age? "))
if Age > 18:
    print("Over 18")
else:
    print("Under 18")
